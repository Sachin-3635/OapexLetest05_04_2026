import * as React from "react";
import "./userDashboardsc.scss";
interface UserDashboardProps {
    context: any;
}
declare const APperformerDashboard: React.FC<UserDashboardProps>;
export default APperformerDashboard;
//# sourceMappingURL=APperformerDashboard.d.ts.map