import * as React from "react";
import "./advanced.scss";
import "bootstrap/dist/css/bootstrap.min.css";
interface IProps {
    context: any;
    itemId: number;
}
declare const APperformerAdvanceform: React.FC<IProps>;
export default APperformerAdvanceform;
//# sourceMappingURL=APperformerAdvanceform.d.ts.map