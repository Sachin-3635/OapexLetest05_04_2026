/// <reference types="react" />
import "bootstrap/dist/css/bootstrap.min.css";
declare const EditAdvanceForm: ({ context, formData, onClose }: any) => JSX.Element;
export default EditAdvanceForm;
//# sourceMappingURL=EditAdvanceForm.d.ts.map