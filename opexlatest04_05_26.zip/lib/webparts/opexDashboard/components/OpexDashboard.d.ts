/// <reference types="react" />
import './usersite.scss';
import { IOpexDashboardProps } from './IOpexDashboardProps';
export default function OpexDashboard(props: IOpexDashboardProps): JSX.Element;
//# sourceMappingURL=OpexDashboard.d.ts.map