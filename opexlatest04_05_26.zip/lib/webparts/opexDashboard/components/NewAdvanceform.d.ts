/// <reference types="react" />
import "./advanced.scss";
import "bootstrap/dist/css/bootstrap.min.css";
declare const NewAdvanceform: ({ context }: any) => JSX.Element;
export default NewAdvanceform;
//# sourceMappingURL=NewAdvanceform.d.ts.map