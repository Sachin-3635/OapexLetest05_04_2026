declare const styles: {};
export default styles;
//# sourceMappingURL=userDashboardsc.scss.d.ts.map