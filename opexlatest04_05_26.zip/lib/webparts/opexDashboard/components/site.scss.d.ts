declare const styles: {};
export default styles;
//# sourceMappingURL=site.scss.d.ts.map