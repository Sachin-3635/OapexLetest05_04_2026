declare const styles: {};
export default styles;
//# sourceMappingURL=advanced.scss.d.ts.map