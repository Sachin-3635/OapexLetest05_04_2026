/// <reference types="react" />
import 'bootstrap/dist/css/bootstrap.min.css';
declare const ViewAdvanceForm: ({ context, formData, onClose }: any) => JSX.Element;
export default ViewAdvanceForm;
//# sourceMappingURL=ViewAdvanceForm.d.ts.map