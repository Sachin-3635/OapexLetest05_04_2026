import * as React from "react";
import "./advanced.scss";
import 'bootstrap/dist/css/bootstrap.min.css';
interface IProps {
    context: any;
    itemId: number;
}
declare const ApproverAdvanceForm: React.FC<IProps>;
export default ApproverAdvanceForm;
//# sourceMappingURL=ApproverAdvanceForm.d.ts.map