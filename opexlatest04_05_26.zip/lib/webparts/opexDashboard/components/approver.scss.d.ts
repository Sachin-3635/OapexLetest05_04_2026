declare const styles: {};
export default styles;
//# sourceMappingURL=approver.scss.d.ts.map