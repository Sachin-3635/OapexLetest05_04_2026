declare const styles: {};
export default styles;
//# sourceMappingURL=usersite.scss.d.ts.map