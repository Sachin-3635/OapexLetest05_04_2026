import * as React from "react";
import "./userDashboardsc.scss";
interface UserDashboardProps {
    context: any;
}
declare const ApproverDashboard: React.FC<UserDashboardProps>;
export default ApproverDashboard;
//# sourceMappingURL=ApproverDashboard.d.ts.map