declare const styles: {
    opexDashboard: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=OpexDashboard.module.scss.d.ts.map