
require("./OpexDashboard.module.css");
const styles = {
  opexDashboard: 'opexDashboard_5e130e66',
  teams: 'teams_5e130e66',
  welcome: 'welcome_5e130e66',
  welcomeImage: 'welcomeImage_5e130e66',
  links: 'links_5e130e66'
};

export default styles;
