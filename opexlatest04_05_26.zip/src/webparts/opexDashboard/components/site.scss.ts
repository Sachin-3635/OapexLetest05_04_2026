
require("./site.css");
const styles = {

};

export default styles;
