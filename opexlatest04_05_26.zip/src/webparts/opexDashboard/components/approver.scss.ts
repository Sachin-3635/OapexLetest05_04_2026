
require("./approver.css");
const styles = {

};

export default styles;
